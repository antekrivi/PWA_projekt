<!DOCTYPE html>
<html>
<head>
    <title>WELT - Unos</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WELT</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
        include 'connect.php';
        define('UPLPATH', 'images/');

        $id = $_GET['id'];
    ?>

    <header class="header">
        <h1>WELT</h1>
    </header>

    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="kategorija.php?id=beruf_karriere">Beruf & Karriere</a>
        <a href="kategorija.php?id=food">Food</a>
        <a href="administracija.php">Administration</a>
        <a href="logout.php">Log out</a>
    </nav>

    <section class="content">

        <article class="section">
            
            <?php
            $query = "SELECT * FROM vijesti WHERE id = $id ";
            $result = mysqli_query($dbc, $query);

            while($row = mysqli_fetch_array($result)) {
                echo '<div class="solo_article">';
                echo '<h2>' . $row['naslov'] . '</h2>';
                echo '<img src="' . UPLPATH . $row['slika'] . '" alt="Article Image" style="width:100%;" >';
                echo '<div class="article-content">';
                echo '<p>' . $row['sazetak'] . '</p>';
                echo '<p class="date">' . $row['datum'] . '</p>';
                echo '<p>' . $row['tekst'] . '</p>';
                echo '</div>';
                echo '</div>';
            }?>
        </article>
    </section>

    <footer>
        <p>Ante Krivačić akrivacic@tvz.hr</p>
    </footer>

</body>
</html>