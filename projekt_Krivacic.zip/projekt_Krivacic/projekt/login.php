<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekt";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$user = $_POST['username'];
$pass = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM korisnik WHERE korisnicko_ime=?");
$stmt->bind_param("s", $user);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();
    if (password_verify($pass, $row['lozinka'])) {
        $_SESSION['username'] = $user;
        $_SESSION['razina'] = $row['razina'];

        if ($row['razina'] == '1') {

            header("Location: administracija.php");
        } else {
            header("Location: index.php");
        }
    } else {
        echo "Invalid password.";
    }
} else {
    
}

$conn->close();
?>