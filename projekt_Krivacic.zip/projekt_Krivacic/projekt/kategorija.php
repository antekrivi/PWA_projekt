<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WELT - Kategorie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    include 'connect.php';
    define('UPLPATH', 'images/');

    $id = $_GET['id'];
    if($id == 'beruf_karriere') {
        $category = 'Beruf & Karriere';
    }
    if($id == 'food') {
        $category = 'Food';
    }
    ?>

    <header class="header">
        <h1>WELT</h1>
    </header>

    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="kategorija.php?id=beruf_karriere">Beruf & Karriere</a>
        <a href="kategorija.php?id=food">Food</a>
        <a href="administracija.php">Administration</a>
        <a href="logout.php">Log out</a>
    </nav>

    <section class="content">

        <article class="section">
            <?php echo '<h2>' . $category . '</h2>' ?>
            <div class="articles">
                <?php
                $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$id' ORDER BY datum DESC";
                $result = mysqli_query($dbc, $query);
                $i=0;
                while($row = mysqli_fetch_array($result)) {
                    echo '<div class="article">';
                    echo '<img src="' . UPLPATH . $row['slika'] . '" alt="Article Image">';
                    echo '<div class="article-content">';
                    echo '<a href="clanak.php?id=' . $row['id'] . '">';
                    echo '<h3>' . $row['naslov'] . '</h3>';
                    echo '</a>';
                    echo '<p>' . $row['sazetak'] . '</p>';
                    echo '<p class="date">' . $row['datum'] . '</p>';
                    echo '</div>';
                    echo '</div>';
                    $i++;
                }?>
            </div>
        </article>
    </section>

    <footer>
        <p>Ante Krivačić akrivacic@tvz.hr</p>
    </footer>

</body>
</html>