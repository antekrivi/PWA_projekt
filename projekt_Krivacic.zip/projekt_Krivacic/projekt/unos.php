<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $image = $_FILES['image']['name'];
    $date = date("d.m.Y.");

    $title = $dbc->real_escape_string($_POST['title']);
    $shortContent = $dbc->real_escape_string($_POST['shortContent']);
    $content = $dbc->real_escape_string($_POST['content']);
    $category = $dbc->real_escape_string($_POST['category']);
    $showOnPage = isset($_POST['checkbox']) ? 1 : 0;

    $target_dir = 'images/'.$image;
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir);

    $query = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva)
    VALUES ('$date', '$title', '$shortContent', '$content', '$image', '$category', '$showOnPage')";

    $query = "INSERT INTO vijesti (naslov) VALUES ('$title')";
    
    $result = mysqli_query($dbc, $query) or die('Error querying database.');
    mysqli_close($dbc);

    header("Location: administracija.php");
    exit();
}

?>