$(document).ready(function() {
    $("#slanje").click(function(event) {
        var slanjeForme = true;

        // Naslov vjesti (5-30 znakova)
        var poljeTitle = $("#title");
        var title = $("#title").val();

        if (title.length > 5 && title.length < 30) {
            poljeTitle.css("border", "1px solid green");
            $("#porukaTitle").html("");
        } else {
            slanjeForme = false;
            poljeTitle.css("border", "1px dashed red");
            $("#porukaTitle").html("Naslov vjesti mora imati između 5 i 30 znakova!<br>");
        }

        // Kratki sadržaj (10-100 znakova)
        var poljeAbout = $("#shortContent");
        var about = $("#shortContent").val();
        if (about.length < 10 || about.length > 100) {
            slanjeForme = false;
            poljeAbout.css("border", "1px dashed red");
            $("#porukaAbout").html("Kratki sadržaj mora imati između 10 i 100 znakova!<br>");
        } else {
            poljeAbout.css("border", "1px solid green");
            $("#porukaAbout").html("");
        }

        // Sadržaj mora biti unesen
        var poljeContent = $("#content");
        var content = $("#content").val();
        if (content.length == 0) {
            slanjeForme = false;
            poljeContent.css("border", "1px dashed red");
            $("#porukaContent").html("Sadržaj mora biti unesen!<br>");
        } else {
            poljeContent.css("border", "1px solid green");
            $("#porukaContent").html("");
        }

        // Slika mora biti unesena
        var poljeSlika = $("#image");
        var pphoto = $("#image").val();
        if (pphoto.length == 0) {
            slanjeForme = false;
            poljeSlika.css("border", "1px dashed red");
            $("#porukaSlika").html("Slika mora biti unesena!<br>");
        } else {
            poljeSlika.css("border", "1px solid green");
            $("#porukaSlika").html("");
        }

        // Kategorija mora biti odabrana
        var poljeCategory = $("#category");
        if ($("#category").prop("selectedIndex") == 0) {
            slanjeForme = false;
            poljeCategory.css("border", "1px dashed red");
            $("#porukaKategorija").html("Kategorija mora biti odabrana!<br>");
        } else {
            poljeCategory.css("border", "1px solid green");
            $("#porukaKategorija").html("");
        }

        if (!slanjeForme) {
            event.preventDefault();
        }
    });
});