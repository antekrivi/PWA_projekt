<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <h1>WELT - register</h1>
    </header>
    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="kategorija.php?id=beruf_karriere">Beruf & Karriere</a>
        <a href="kategorija.php?id=food">Food</a>
        <a href="login.html">Administration</a>
        <a href="login.html">Entry</a>
        <a href="logout.php">Log out</a>
    </nav>

    <section class="content">
        <form action="register.php" method="post">
            <h2>Registracija</h2>
            <label for="korisnicko_ime">Korisničko ime:</label><br>
            <input type="text" id="korisnicko_ime" name="korisnicko_ime" required><br>
            
            <label for="ime">Ime:</label><br>
            <input type="text" id="ime" name="ime" required><br>

            <label for="prezime">Prezime:</label><br>
            <input type="text" id="prezime" name="prezime" required><br>

            <label for="lozinka">Lozinka:</label><br>
            <input type="password" id="lozinka" name="lozinka" required><br>

            <label for="ponovi_lozinku">Ponovi lozinku:</label><br>
            <input type="password" id="ponovi_lozinku" name="ponovi_lozinku" required><br>
            <?php
            if (isset($_GET['error'])) {
                echo '<span id="porukaKorisnickoIme" class="error">' . $_GET['error'] . '</span><br><br>';
            }?>

            <input type="submit" value="Registriraj se">
        </form>
    </section>

    <?php
        include 'connect.php';

        session_start();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $korisnicko_ime = $_POST['korisnicko_ime'];
            $ime = $_POST['ime'];
            $prezime = $_POST['prezime'];
            $lozinka = $_POST['lozinka'];
            $ponovi_lozinku = $_POST['ponovi_lozinku'];

            // Provjera lozinki
            if ($lozinka !== $ponovi_lozinku) {
                header("Location: register.php?error=Lozinke se ne podudaraju.");
                exit();
            }

            // Check if username already exists
            $stmt = $dbc->prepare("SELECT * FROM korisnik WHERE korisnicko_ime=?");
            $stmt->bind_param("s", $korisnicko_ime);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                
                header("Location: register.php?error=korisnicko ime vec postoji!");
                exit();
            }

            // Hashiranje lozinke
            $hashed_lozinka = password_hash($lozinka, PASSWORD_DEFAULT);

            // Postavljanje razine korisnika na 0
            $razina = 0;

            // Priprema i izvršenje upita
            $stmt = $dbc->prepare("INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssi", $ime, $prezime, $korisnicko_ime, $hashed_lozinka, $razina);

            if ($stmt->execute()) {

                $_SESSION['username'] = $korisnicko_ime;
                $_SESSION['razina'] = $razina;

                header("Location: login.html");
            } else {
                echo "Greška: " . $stmt->error;
            }

            $stmt->close();
        }

        $dbc->close();
        ?>

    <footer>
        <p>Ante Krivačić akrivacic@tvz.hr</p>
    </footer>
</body>
</html>
