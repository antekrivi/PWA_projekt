<?php
header('Content-Type: text/html; charset=utf-8');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekt";

$dbc = mysqli_connect($servername, $username, $password, $dbname) or die('Error connecting to MySQL server.');
mysqli_set_charset($dbc, "utf8");

if(!$dbc){
    echo "Connection failed!";
}?>
