-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2024 at 02:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `prezime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `korisnicko_ime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `razina`) VALUES
(2, 'Dado', 'Pršo', 'dado', '$2y$10$a5C0iu1Qf/UfqTyJ8TrZWeN3JSLWwkkpGKvBQ.2tCqHpzsqZZeFju', 0),
(4, 'Ante', 'Krivačić', 'ante1', '$2y$10$VrdtqPOsgBeeDR4/Xc0orObFuhB4N2gvTDwh5cQYSTy3f7R.V1hKq', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `sazetak` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `tekst` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `slika` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kategorija` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(2, '2024-06-06 23:48:08', 'Wie Sie dank besserer Körpersprache mehr Erfolg haben', 'Ein souveränes Auftreten kann so manchen physischen Nachteil ausgleichen. Einfach nur gerade zu stehen und Haltung anzunehmen, reicht allerdings nicht. WELT verrät Ihnen die Geheimnisse einer positiven Körpersprache.', 'Ein souveränes Auftreten kann so manchen physischen Nachteil ausgleichen. Einfach nur gerade zu stehen und Haltung anzunehmen, reicht allerdings nicht. WELT verrät Ihnen die Geheimnisse einer positiven Körpersprache.\r\nEs ist nicht nur wichtig, selbstbewusst und dominant zu wirken ? sondern auch sympathisch. Gute Beziehungen zu haben, ein gutes Netzwerk, ist wichtig für den beruflichen Erfolg. Und natürlich auch für das Privatleben. So zeigte etwa eine Studie des University College in London, dass alte Menschen länger leben, wenn sie ein gutes soziales Umfeld haben.\r\n\r\nTatsächlich gibt es einige Möglichkeiten, um Nähe zum Gesprächspartner herzustellen. Zum Beispiel, den Bewegungsrhythmus des anderen zu spiegeln.\r\n\r\nEin souveränes Auftreten kann so manchen physischen Nachteil ausgleichen. Einfach nur gerade zu stehen und Haltung anzunehmen, reicht allerdings nicht. WELT verrät Ihnen die Geheimnisse einer positiven Körpersprache.\r\nEs ist nicht nur wichtig, selbstbewusst und dominant zu wirken ? sondern auch sympathisch. Gute Beziehungen zu haben, ein gutes Netzwerk, ist wichtig für den beruflichen Erfolg. Und natürlich auch für das Privatleben. So zeigte etwa eine Studie des University College in London, dass alte Menschen länger leben, wenn sie ein gutes soziales Umfeld haben.\r\n\r\nTatsächlich gibt es einige Möglichkeiten, um Nähe zum Gesprächspartner herzustellen. Zum Beispiel, den Bewegungsrhythmus des anderen zu spiegeln.\r\n', 'Kombo-Koerpersprache.jpg', 'beruf_karriere', 0),
(3, '2024-06-06 23:49:19', 'Totale Kontrolle !? wenn die App Ihren Feierabend bestimmt', 'Das EuGH-Urteil, nach dem die Arbeitszeit aller Beschäftigten künftig erfasst werden soll, hat eine heftige Debatte losgetreten. Die Technik wäre zwar vorhanden, hat aber einige Haken. Und das ist längst nicht das einzige Problem.', 'Laut EuGH müssen Unternehmen die Arbeitszeit ihrer Angestellten lückenlos erfassen. Doch Arbeit ist nicht gleich Arbeit. In vielen Dienstleistungsberufen wird auch nach Aufgabenerfüllung bezahlt. Und genau hier beginnt das Problem.\r\nAnzeige\r\nDer Aufschrei war groß, als der Europäische Gerichtshof im Mai entschied, dass Unternehmen die Arbeitszeit ihrer Mitarbeiter zu erfassen haben, und zwar die gesamte Arbeitszeit, nicht ? wie bisher ? nur die Überstunden. Nur eine komplette Erfassung stelle sicher, dass der Arbeitnehmer sich gegen ungerechtfertigte Überstunden zur Wehr setzen könne.\r\n\r\nDie Stellungnahmen reichten von ?Unternehmen müssen die Stechuhr wieder einführen? bis hin zu ?Für Deutschland sehe ich keinen Handlungsbedarf?. Beides dürfte so nicht stimmen oder zumindest den Sachverhalt unzuverlässig verkürzen. Ebenso schnell, wie sie aufkam, verebbte die Diskussion dann auch wieder.\r\n\r\nArbeit ist nicht gleich Arbeit\r\nDer EuGH fasst ? wie wir alle ? unter dem Begriff Arbeit eine Vielfalt an Tätigkeiten zusammen, bei denen Arbeitsabläufe, Anforderungen und Selbstverständnis auseinanderklaffen. Ganz einfach gesagt, es bestehen Unterschiede zwischen Rettungssanitätern und Sachbearbeiterinnen, Floristen und Wirtschaftsanwältinnen.', 'food_1.jpg', 'beruf_karriere', 0),
(4, '2024-06-06 23:50:04', 'So schafft Ihr Kind es nach Harvard', 'Wer an einer der acht Ivy-League-Unis studiert, hat beste Karrierechancen. Aber die Auswahlprozesse sind hart. Interessenten sollten sich lange vor dem Abi vorbereiten ? und eine besondere Passion vorweisen. Drei Punkte sind dabei entscheidend.', 'Wer an einer der acht Ivy-League-Unis studiert, hat beste Karrierechancen. Aber die Auswahlprozesse sind hart. Interessenten sollten sich lange vor dem Abi vorbereiten ? und eine besondere Passion vorweisen. Drei Punkte sind dabei entscheidend.\r\nEs war ein Tag, dem Hunderttausende junge Menschen auf der ganzen Welt entgegen fieberten: ?Ivy Day?. Vor rund drei Wochen, am 28. März, teilten Amerikas Elite-Universitäten ihren Bewerben mit, wer es geschafft hat. Die Hochschulen stellten die Ergebnisse der jüngsten Auswahlverfahren ins Internet, zeitgleich, um Punkt 17 Uhr. Und wie jedes Jahr brachte dieser Moment für die meisten Kandidaten eine Enttäuschung.\r\n\r\nDenn nur sehr wenige schaffen den Sprung an eine der sogenannten Ivy-League-Hochschulen. Die meisten Universitäten machen in ihren Auswahlverfahren keinen Unterschied zwischen US-Bürgern und Ausländern. Alle, die sich für einen Bachelor bewerben, müssen dieselben Kriterien erfüllen. Und die Anforderungen sind hoch ? aber mit der richtigen Vorbereitung durchaus zu meistern.\r\n\r\nWer an einer der acht Ivy-League-Unis studiert, hat beste Karrierechancen. Aber die Auswahlprozesse sind hart. Interessenten sollten sich lange vor dem Abi vorbereiten ? und eine besondere Passion vorweisen. Drei Punkte sind dabei entscheidend.\r\nEs war ein Tag, dem Hunderttausende junge Menschen auf der ganzen Welt entgegen fieberten: ?Ivy Day?. Vor rund drei Wochen, am 28. März, teilten Amerikas Elite-Universitäten ihren Bewerben mit, wer es geschafft hat. Die Hochschulen stellten die Ergebnisse der jüngsten Auswahlverfahren ins Internet, zeitgleich, um Punkt 17 Uhr. Und wie jedes Jahr brachte dieser Moment für die meisten Kandidaten eine Enttäuschung.\r\n\r\nDenn nur sehr wenige schaffen den Sprung an eine der sogenannten Ivy-League-Hochschulen. Die meisten Universitäten machen in ihren Auswahlverfahren keinen Unterschied zwischen US-Bürgern und Ausländern. Alle, die sich für einen Bachelor bewerben, müssen dieselben Kriterien erfüllen. Und die Anforderungen sind hoch ? aber mit der richtigen Vorbereitung durchaus zu meistern.', 'harvard.jpg', 'beruf_karriere', 0),
(5, '2024-06-06 23:50:55', 'Zitronenhähnchen aus dem Ofen', 'Allein der Duft, der durch Wohnung zieht, ist es wert: Jeder Mensch sollte wissen, wie man ganzes Huhn brät ? dieses Rezept gelingt selbst Anfängern. Die Beilage? Schmort einfach mit dem Fleisch im Ofen. Einfacher geht es kaum.', 'Allein der Duft, der durch Wohnung zieht, ist es wert: Jeder Mensch sollte wissen, wie man ein ganzes Huhn brät - und dieses Rezept gelingt selbst Anfängern. Die Beilage? Schmort einfach mit dem Fleisch im Ofen. Einfacher geht es kaum.\r\nBei diesem hier bemühen wir die klassische Kombination Hähnchen und Zitrone, und die Beilage, nämlich die kleinen Kartoffeln, garen gleich mit. Das macht sie fast noch wohlschmeckender als das Fleisch,\r\n\r\nAllein der Duft, der durch Wohnung zieht, ist es wert: Jeder Mensch sollte wissen, wie man ein ganzes Huhn brät - und dieses Rezept gelingt selbst Anfängern. Die Beilage? Schmort einfach mit dem Fleisch im Ofen. Einfacher geht es kaum.\r\nBei diesem hier bemühen wir die klassische Kombination Hähnchen und Zitrone, und die Beilage, nämlich die kleinen Kartoffeln, garen gleich mit. Das macht sie fast noch wohlschmeckender als das Fleisch,\r\n\r\n', 'food_1.jpg', 'food', 0),
(6, '2024-06-06 23:51:41', 'Nicht scharf genug? Diese Soßen sollten Sie kennen', 'Ob zum Marinieren, Kochen oder Nachwürzen: Fünf scharfe Soßen, mit denen Sie Ihrem Gewürzarsenal ein Upgrade verpassen ? und die Rezepte, in denen sie besonders gut zur Geltung kommen.', 'Ob zum Marinieren, Kochen oder Nachwürzen: Fünf scharfe Soßen, mit denen Sie Ihrem Gewürzschrank ein Upgrade verpassen - und die Rezepte, in denen sie besonders gut zur Geltung kommen.\r\nAnzeige\r\nNichts gegen die Flasche Tabasco, die in vielen Küchenschränken zwischen Essig, Öl und Maggi ihr Dasein fristet. Und nichts gegen höllisch scharfe, frisch geschnittene Chilischoten. Wenn Sie es richtig scharf lieben, könnte es sich aber lohnen, noch ein paar weitere Soßen und Pasten in Ihr Arsenal aufzunehmen. Denn die scharfen Schoten sind in der Küche vieler Kulturen ein fester Bestandteil - aber kommen doch in sehr unterschiedlichen Versionen zum Einsatz.\r\n\r\nChipotle\r\nDie rauchigere Cousine der herkömmlichen Chilischote ist gerade schwer im Trend. Wir haben damit ein Pulled Pork gewürzt, das kombiniert mit Tacos und Guacamole eine schöne Grundlage für ein unkompliziertes Essen mit Freunden bildet. Auch einer frischen Tomaten-Salsa oder Eintöpfen kann Chipotle etwas rauchige Tiefe verleihen.\r\n\r\nLESEN SIE AUCH\r\nPulled Pork Tacos\r\nMEXIKO TRIFFT DIE USA\r\nTacos mit Chipotle Pulled Pork\r\nUnser Tipp: Chipotles in Adobo* werden in kleinen Dosen verkauft - oft braucht man aber wirklich nur einen oder zwei Teelöffel voll. Damit der Rest nicht verschwendet wird, können Sie daraus eine extrem einfache, dafür aber vielseitig einsetzbare Soße herstellen: Einfach den Inhalt einer kleinen Dose Chipotles (abzüglich dessen, was Sie schon verbraucht haben) mit 200 ml Apfelessig und 1/2 Tl Salz und 1 EL Honig oder Agavensirup* pürieren. In eine saubere, verschließbare Flasche (oder Glas) abgefüllt hält sich ihre hausgemachte Chipotle-Salsa im Kühlschrank ca. 4 Wochen.', 'food2.jpg', 'food', 0),
(7, '2024-06-06 23:52:48', 'Spaghetti all? ubriaco', 'Dieses Gericht lebt von zwei Zutaten, die einander ergänzen: Pasta und Wein. Als Kombination ein Klassiker. Doch bei den Spaghetti ?nach Säuferart? kommt der Rotwein direkt mit in den Topf.', 'Das steht schon so lange auf meiner Liste, und jetzt ist die Gelegenheit da. Der Kochtopf feiert Geburtstag ? den 18. Und weil man da ja volljährig wird, darf man auch mal einen heben. Da ist es nur konsequent, dass Zorra sich Rezepte mit Schwips wünscht.\r\n\r\nAber erstmal ? Happy Birthday und vielen Dank ? für Deine Ideen, Dein Durchhaltevermögen, die Energie, mit der Du Events organisierst und uns alle vernetzt; das ist wirklich eine Ausnahmeerscheinung, und zwar eine großartige!\r\n\r\nBlog-Event CLXXXIX - Rezepte mit Schwips zum 18. kochtopf-Geburtstag! (Einsendeschluss 15. September 2022)\r\nJetzt aber zum Rezept: Spaghetti all?Ubriaco heißt ?betrunkene Spaghetti? und Wein spielt da eine gewisse Rolle. Die Pasta wird in etwas Rotwein gegart und saugt ihn auf, das ergibt einen tollen Geschmack. Hier dürfen außerdem noch Walnüsse, Chiliflocken und Knoblauch mitspielen ? und Pecorino, der kann gut mit dem Weinaroma mithalten.', 'food3.jpg', 'food', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
